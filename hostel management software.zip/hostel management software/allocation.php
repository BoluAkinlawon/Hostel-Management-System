<?php
session_start();
if(!isset($_SESSION['matric_number'])){
	echo"You are not logged in to see content";
	header("login.php");
}else{
	//echo '<script type ="text/javascript">alert("Welcome")</script>';
}


?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<body align=center>
<style>
body {
   background: url(image3.jpg) no-repeat; 

  
}
text{
	width:100%;
	height: 5%;
	border: 1px solid brown;
	border-radius: 05px;
	padding: 20px 15px 20px 15px;
	margin: 10px 0px 15 px 0px;
}

</style>
<div style="background:; width:97%; height:600px; border:1px solid black;padding:15px;">
</head>


</style>


<?php




?>

<?php require "includes/header.php"; ?>
<font face="verdana">
<body>
<h2 align= center></h2>

<div style="text-align:center; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;">
<center>
<h2>Input your details to get your room allocation</h2>
</center>
<form  method="post" action="insert.php">
    <label for="matric">Matric Number</label><br>
    <input type="text" name="matric" id="matric" required style="width: 300px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px"><br>
    
	<label for="department">Department</label><br>
     <select name="department" style ="border: 1px solid brown; border-radius: 05px; padding: 15px 10px 15px 10px; margin: 10px 0px 15 px 0px; text-align:center;">
	<option value="" style = "text-align:center;">--Select--</option>
	<option value="Computer Science">Computer Science</option>
	<option value="History and International Relations">History and International Relations</option>
	<option value="Economics">Economics</option>
	<option value="Law">Law</option>
	</select><br><br>
	
	<label for="level">Level</label><br>
   <select name="level" style= "border: 1px solid brown; border-radius: 05px; padding: 15px 10px 15px 10px; margin: 10px 0px 15 px 0px;">
	<option value="">--Select--</option>
	<option value="100">100</option>
	<option value="200">200</option>
	<option value="300">300</option>
	<option value="400">400</option>
	</select><br><br>
	
	
	<input type="submit" name="submit" value="Get your room allocation">
	</form>

	</div>
</font>
</body>


</html>
<center>

</center>