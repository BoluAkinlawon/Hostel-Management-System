<?php
$user_name = "root";
$password = "";
$database = "rooms";
$server = "localhost";


$con = mysqli_connect("localhost","root","","rooms");






?>