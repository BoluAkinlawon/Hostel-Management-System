<?php
 include "includes/header.php";
 
$link = mysqli_connect("localhost", "root", "", "rooms");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$matric = mysqli_real_escape_string($link, $_REQUEST['matric']);
$department = mysqli_real_escape_string($link, $_REQUEST['department']);
$level = mysqli_real_escape_string($link, $_REQUEST['level']);
if ($department=="Computer Science" && strpos($matric, "CMP") == 4 && $level == "400"){
    $block = rand(1, 18);
	$num= rand(1, 4);
	switch($num){
	case 1: $room_no=1;
	break;
	case 2: $room_no=24;
	break;
	case 3: $room_no=12;
	break;
	case 4: $room_no=13;
	break;
	
	}
}elseif($department=="History and International Studies" && strpos($matric, "CMP") == 4 && $level == "400"){
	$block = rand(1, 18);
	$num= rand(1, 4);
	switch($num){
	case 1: $room_no=1;
	break;
	case 2: $room_no=24;
	break;
	case 3: $room_no=12;
	break;
	case 4: $room_no=13;
	break;	
}
}
elseif($department=="Economics" && strpos($matric, "CMP") == 4 && $level == "400"){
	$block = rand(1, 18);
	$num= rand(1, 4);
	switch($num){
	case 1: $room_no=1;
	break;
	case 2: $room_no=24;
	break;
	case 3: $room_no=12;
	break;
	case 4: $room_no=13;
	break;	
}
}
elseif($department=="Law" && strpos($matric, "CMP") == 4 && $level == "400"){
	$block = rand(1, 18);
	$num= rand(1, 4);
	switch($num){
	case 1: $room_no=1;
	break;
	case 2: $room_no=24;
	break;
	case 3: $room_no=12;
	break;
	case 4: $room_no=13;
	break;	
}
}
elseif($department=="Computer Science" && $level == "300"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="History and International Studies" && $level == "300"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="Economics" && $level == "300"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="Law" && $level == "300"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="Computer Science" && $level == "200"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="History and International Studies" && $level == "200"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="Economics" && $level == "200"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="Law" && $level == "200"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="Computer Science" && $level == "100"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="History and International Studies" && $level == "100"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="Economics" && $level == "100"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
elseif($department=="Law" && $level == "100"){
	$block = rand(1, 18);
    $room_no= rand(2, 23);	
}
else{
	echo "Invalid";
}

 
// Attempt insert query execution
$sql = "INSERT INTO hostel (matric_number, department, level, block, room_no) VALUES ('$matric', '$department', '$level' , '$block' ,'$room_no')";
if(mysqli_query($link, $sql)){
	echo "<h1><p align = center>Your room number is block $block room $room_no ";
   //echo '<script language="javascript">';
   //echo 'alert(""Your room number is block $block room $room_no "")';
   //echo '</script>';
} else{
	echo "" ;
	echo '<script>javascript: alert("")></script>';
	echo '<script language="javascript">';
echo 'alert("You have already been allocated")';
echo '</script>';
    //echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>

 <html>
<style>
body {
   background: url(image3.jpg) no-repeat; 

  
}
text{
	width:100%;
	height: 5%;
	border: 1px solid brown;
	border-radius: 05px;
	padding: 20px 15px 20px 15px;
	margin: 10px 0px 15 px 0px;
}
</style>
</html>
<?php include "includes/footer.php";?>