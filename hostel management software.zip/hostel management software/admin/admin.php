<?php
include "includes/header.php"; 
  include "includes/footer.php";


?>

<html>
<style>
body {
   background: url(image3.jpg) no-repeat; 

  
}
text{
	width:100%;
	height: 5%;
	border: 1px solid brown;
	border-radius: 05px;
	padding: 20px 15px 20px 15px;
	margin: 10px 0px 15 px 0px;
}
</style>
</html>