<html>

<body align=center>
<link rel="stylesheet" href="form.css" >
<div style="background-color:gray; font-family: 'arial', sans-serif; color:white;">

</div>			
</div>

<style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: gray;
  color: white;
  text-align: center;
}
</style>

<div class="footer">
<p align="center"></p>
			<p align="center"></p>
</div>

</body>

</html>