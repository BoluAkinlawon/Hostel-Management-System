<?php
 include "includes/header.php";
 include "includes/footer.php";

?>

<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
  body {
   background: url(image3.jpg) no-repeat; 

  
}
text{
	width:100%;
	height: 5%;
	border: 1px solid brown;
	border-radius: 05px;
	padding: 20px 15px 20px 15px;
	margin: 10px 0px 15 px 0px;
}
<head>

        

</head>

  </style>
  <body>
   <div id = "main">
  <div style="text-align:center; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;">
  <h1 align= "center">LOGIN</h1>
  <form method ="POST" align="center">
          Username
		  <input type="text" name = "Username" class ="text" autocomplete="off" required style="width: 300px; height: 1px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px"><br>
		  Password
		  <input type="text" name = "Password" class ="text" required style="width: 300px; height: 1px; text=border: 3px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px"><br>
		  <input type = "SUBMIT" name ="submit" id= "sub">
		  
  </form>
  </div>
           

        </body>

</html>

