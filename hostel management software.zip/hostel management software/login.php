<?php include "includes/header.php";?>

<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
  body {
   background: url(image3.jpg) no-repeat; 
   font-family:Cambria;
  
}
text{
	width:80%;
	height: 15px;
	border: 1px solid brown;
	border-radius: 05px;
	padding: 20px 15px 20px 15px;
	margin: 10px 0px 15 px 0px;
}
<head>
<link rel="stylesheet" href="css/style.css">
	    <link rel="shortcut icon" href="images/hms.ico">

        <body>
           

        </body>

</head>



  </style>

</html>


<?php

$connection = mysqli_connect("localhost","root", "");
$db = mysqli_select_db($connection, "rooms");

if(isset($_POST['submit'])){
	$matric = $_POST['matric'];
	$password = $_POST['password'];
	
	$query = "SELECT * from users where matric_number = '$matric' and password = '$password'";
	$query_run = mysqli_query($connection, $query);
	
	if($query_run -> num_rows > 0){
		session_start();
		$_SESSION['matric_number'] = $matric;
		header("location:allocation.php");
		
	}
	else{
		header("location:register.php");
	}
	
}
?>

<div style ="width:100%; height:458px;">
<center>
<fieldset style ="width:200px; height:250px; border-radius:5px; text-border:1px black; ">
<h2 align= center>Login</h2>
<hr>
<center>
<form action="" method= "post" id ="login">
		     <label for="matric"><font face="verdana">Matric Number</label><br>
                     <input type="text" name="matric" id="matric" required style="width: 200px; height: 2px; text-border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"><br>
			 <label for="password">Password</label><br>
                     <input type="password" name="password" id="password" required style="width: 200px; height: 2px; text-border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"><br>
			 
			 <input type ="submit" name = "submit" style ="width:90px; height:20px; border-radius: 5px;"></input>
			 
           </form>
</center>
</fieldset>		 
</center>
		   
</div>



<?php include "includes/footer.php";?>