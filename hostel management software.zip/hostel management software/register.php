<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<body align=center>
<style>

body {
   background: url("image3.jpg") no-repeat; 
   font-family:Cambria;
   
  
}
text{
	width:100%;
	height: 5%;
	border: 1px solid brown;
	border-radius: 05px;
	padding: 20px 15px 20px 15px;
	margin: 10px 0px 15 px 0px;
}

</style>



<?php


/**
 * Use an HTML form to create a new entry in the
 * users table.
 *
 */

$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, "rooms");


if (isset($_POST['submit'])) {
   
 $firstname = $_POST["firstname"];
 $lastname = $_POST["lastname"];
 $password = $_POST["password"];
 $gender = $_POST["gender"];
 $matric_number = $_POST["matric"];
 $level = $_POST["level"];
 $student_phone = $_POST["phonenumber"];
 $parent_phone = $_POST["parentphone"];
		
		$query = "INSERT into users(firstname, lastname, password, gender, matric_number, level, student_phone, parent_phone) VALUES ('$firstname', '$lastname', '$password', '$gender', '$matric_number', '$level', '$student_phone', '$parent_phone')";
	    $query_run = mysqli_query($connection, $query);
		
		if($query_run){
			header("location:login.php");
			
		}
		else{
			echo"Error";
		}
}
       
?>

<?php require "includes/header.php"; ?>



<body>


<div style="text-align:center; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;">

<center>
<fieldset style ="border-radius:5px; width: 350px;">
<h2 align= center>Register</h2>
<hr>
<center>
<form  method="post">
    <label for="firstname"></label><br>
    <input type="text" name="firstname" id="firstname" placeholder = "First Name" required style="width: 300px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px; text-align:center;"><br>
    
	<label for="lastname"></label><br>
    <input type="text" name="lastname" id="lastname" placeholder = "Last Name" required style="width: 300px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px; text-align:center;"><br>
	
	<label for="password"></label><br>
    <input type="password" name="password" id="password" placeholder = "Password" required style="width: 300px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px; text-align:center;"><br>
	
	<label for="gender">Gender</label><br>
	<select name="gender">
	<option value="">--Select--</option>
	<option value="Male">Male</option>
	<option value="Female">Female</option>
	</select><br><br>
	
	<label for="matric"></label><br>
    <input type="text" name="matric" id="matric" placeholder = "Matric Number" required style="width: 300px; height: 30px; text-border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px; text-align:center;"><br>
	
	<label for="level">Level</label><br>
	<select name="level" >
	<option value="">--Select--</option>
	<option value="100">100</option>
	<option value="200">200</option>
	<option value="300">300</option>
	<option value="400">400</option>
	</select><br><br>
	
	<label for="phonenumber"></label><br>
    <input type="text" name="phonenumber" id="phonenumber" placeholder = "Phone Number" required style="width: 300px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px; text-align:center;"><br>
	
	<label for="parentphone"></label><br>
    <input type="text" name="parentphone" id="parentphone" placeholder = "Parent/Guardian Phone number" required style="width: 300px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px; text-align:center;"><br>
	<br>
	<button type="submit" name="submit" value="Submit" style ="width:90px; height:20px; border-radius: 5px;">Register</button>
	</form>
	</center>
</fieldset>
</center>

</body>
	

<?php require "includes/footer.php"; ?>

</html>
