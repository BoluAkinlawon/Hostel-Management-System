admin login username: admin
password:12345678
create database "rooms"
import rooms.sql into the created database